Hello there!!!
Thanks for downloading NEW CLASS font and taking time reading this note.

NOTE: This font is for PERSONAL USE ONLY. 

If you want to use for commercial purpose, you can purchase here:
https://www.creativefabrica.com/product/thunder-boom/ref/236930/

Visit our store at:
https://www.creativefabrica.com/designer/airotype/ref/236930/

Thank you so much...

Have fun and good luck!!!